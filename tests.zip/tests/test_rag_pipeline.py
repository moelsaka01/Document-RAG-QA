from src.rag_pipeline import RAGPipeline


def test_retrieve_non_empty():
    pipeline = RAGPipeline()
    results = pipeline.retrieve("What is Retrieval Augmented Generation?", top_k=3)
    assert len(results) > 0
    assert results[0].score <= 1.0


def test_generate_answer_returns_text():
    pipeline = RAGPipeline()
    answer, retrieved = pipeline.generate_answer("How do you deploy AI systems?", top_k=3)
    assert isinstance(answer, str)
    assert len(answer) > 0
    assert isinstance(retrieved, list)
