from fastapi.testclient import TestClient

from src.api import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data.get("status") == "ok"


def test_ask_endpoint():
    payload = {"query": "What is Retrieval Augmented Generation?", "top_k": 2}
    response = client.post("/ask", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "answer" in data
    assert "retrieved_chunks" in data
    assert isinstance(data["retrieved_chunks"], list)
    assert len(data["retrieved_chunks"]) > 0
