from typing import List
from pathlib import Path


def list_text_files(directory: Path) -> List[Path]:
    if not directory.exists():
        raise FileNotFoundError(f"Directory does not exist: {directory}")
    return sorted([p for p in directory.iterdir() if p.suffix.lower() == ".txt"])
