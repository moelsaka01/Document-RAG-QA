from dataclasses import dataclass
from pathlib import Path
from typing import List

from .utils import list_text_files


@dataclass
class DocumentChunk:
    doc_id: str
    chunk_id: int
    text: str


def load_documents_as_chunks(
    docs_dir: Path,
    max_chars: int = 250,
    overlap: int = 60,
) -> List[DocumentChunk]:
    """
    Load all .txt documents in docs_dir and split into overlapping chunks.

    Smaller max_chars + some overlap gives us more (and smoother) chunks,
    which is closer to a real RAG setup.
    """
    chunks: List[DocumentChunk] = []
    text_files = list_text_files(docs_dir)

    for file_path in text_files:
        doc_id = file_path.name
        raw_text = file_path.read_text(encoding="utf-8")
        # normalize whitespace a bit
        raw_text = " ".join(raw_text.split())

        start = 0
        chunk_id = 0
        while start < len(raw_text):
            end = start + max_chars
            chunk_text = raw_text[start:end]
            chunks.append(
                DocumentChunk(
                    doc_id=doc_id,
                    chunk_id=chunk_id,
                    text=chunk_text,
                )
            )
            if end >= len(raw_text):
                break
            # overlap so we do not cut information too harshly
            start = end - overlap
            chunk_id += 1

    if not chunks:
        raise ValueError(f"No chunks produced from directory: {docs_dir}")
    return chunks
    