import json
from datetime import datetime
from typing import List, Dict, Any

from .config import LOGS_DIR
from .rag_pipeline import RAGPipeline


def evaluate_queries(pipeline: RAGPipeline, eval_data: List[Dict[str, Any]], top_k: int = 3) -> Dict[str, Any]:
    results = []
    reciprocal_ranks = []
    hits = 0

    for item in eval_data:
        query = item["query"]
        expected_doc_id = item["expected_doc_id"]
        retrieved = pipeline.retrieve(query, top_k=top_k)
        retrieved_ids = [c.doc_id for c in retrieved]

        hit = expected_doc_id in retrieved_ids
        if hit:
            rank = retrieved_ids.index(expected_doc_id) + 1
            rr = 1.0 / rank
            reciprocal_ranks.append(rr)
            hits += 1
        else:
            reciprocal_ranks.append(0.0)

        results.append(
            {
                "query": query,
                "expected_doc_id": expected_doc_id,
                "retrieved_doc_ids": retrieved_ids,
                "hit": hit,
                "reciprocal_rank": reciprocal_ranks[-1],
            }
        )

    hit_rate = hits / len(eval_data) if eval_data else 0.0
    mrr = sum(reciprocal_ranks) / len(reciprocal_ranks) if reciprocal_ranks else 0.0

    metrics = {
        "top_k": top_k,
        "hit_rate_at_k": hit_rate,
        "mean_reciprocal_rank": mrr,
    }

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "metrics": metrics,
        "queries": results,
    }


def main():
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    eval_queries = [
        {"query": "What is Retrieval Augmented Generation?", "expected_doc_id": "rag_intro.txt"},
        {"query": "How do you deploy AI systems with Docker?", "expected_doc_id": "deployment_guide.txt"},
        {"query": "What are some basic steps in a machine learning project?", "expected_doc_id": "ml_basics.txt"},
    ]

    pipeline = RAGPipeline()
    eval_result = evaluate_queries(pipeline, eval_queries, top_k=3)

    log_path = LOGS_DIR / "eval_logs.json"
    log_obj = {
        "last_run": eval_result["timestamp"],
        "top_k": eval_result["metrics"]["top_k"],
        "metrics": eval_result["metrics"],
        "queries": eval_result["queries"],
    }

    with log_path.open("w", encoding="utf-8") as f:
        json.dump(log_obj, f, indent=2)

    print("Evaluation complete.")
    print(f"Hit rate@k: {eval_result['metrics']['hit_rate_at_k']:.3f}")
    print(f"MRR: {eval_result['metrics']['mean_reciprocal_rank']:.3f}")
    print(f"Results saved to {log_path}")


if __name__ == "__main__":
    main()
