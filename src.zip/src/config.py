from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

DOCS_DIR = BASE_DIR / "data" / "docs"
LOGS_DIR = BASE_DIR / "logs"

EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

DEFAULT_TOP_K = 3
